package com.codestates.seb.kdelivery;

public class Order {
  private String customerName;
  private String shopName;
  private String foodName;

  /**
  *@Order():주문 정보를 저장합니다.
  **/

}
