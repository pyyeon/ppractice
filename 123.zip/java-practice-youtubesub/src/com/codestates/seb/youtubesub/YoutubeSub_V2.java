package com.codestates.seb.youtubesub;

public class YoutubeSub_V2 {
    //최대한 모듈화
    //로그인 정보가 다르다면 같을때까지 재 입력
    //배열을,리스트로
    //사용된 비속어 출력
    // 비속어와 비속어를 순회한 단어를 한 쌍으로
}
